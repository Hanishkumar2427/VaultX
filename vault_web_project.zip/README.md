# Vault - Distributed Object Storage Web Prototype

## Requirements
- Python 3.10+
- pip

## Setup
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn app:app --reload
```

Open http://127.0.0.1:8000

## Main API
- `POST /objects` upload an object (`file` form field)
- `GET /objects/{object_id}` download an object
- `GET /objects` list objects
- `GET /nodes` inspect nodes
- `POST /nodes/{node_id}/fail` simulate node failure
- `POST /nodes/{node_id}/recover` recover a node
- `POST /repair` repair missing/corrupt replicas
- `POST /rebalance` rebalance replicas
- `POST /verify` verify all replicas
- `GET /docs` interactive Swagger API docs

This is an educational prototype. Metadata uses SQLite with a process lock, while each storage node is represented by a local directory.

import hashlib
import json
import os
import shutil
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Dict, List

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent
DATA_DIR = BASE / "vault_storage"
DB_PATH = BASE / "vault.db"
REPLICATION_FACTOR = 3
NODE_COUNT = 5
CHUNK_SIZE = 1024 * 1024

app = FastAPI(title="Vault", version="1.0.0")
db_lock = threading.RLock()
node_lock = threading.RLock()


def connect_db():
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    DATA_DIR.mkdir(exist_ok=True)
    with db_lock, connect_db() as db:
        db.execute("""
        CREATE TABLE IF NOT EXISTS objects (
            object_id TEXT PRIMARY KEY,
            object_name TEXT NOT NULL,
            size INTEGER NOT NULL,
            checksum TEXT NOT NULL,
            created_at REAL NOT NULL,
            version INTEGER NOT NULL DEFAULT 1
        )
        """)
        db.execute("""
        CREATE TABLE IF NOT EXISTS replicas (
            object_id TEXT NOT NULL,
            node_id TEXT NOT NULL,
            checksum TEXT NOT NULL,
            size INTEGER NOT NULL,
            version INTEGER NOT NULL,
            PRIMARY KEY (object_id, node_id)
        )
        """)
        db.execute("""
        CREATE TABLE IF NOT EXISTS nodes (
            node_id TEXT PRIMARY KEY,
            active INTEGER NOT NULL DEFAULT 1,
            capacity INTEGER NOT NULL DEFAULT 10737418240
        )
        """)
        for i in range(1, NODE_COUNT + 1):
            node_id = f"node-{i}"
            db.execute(
                "INSERT OR IGNORE INTO nodes(node_id, active) VALUES(?, 1)",
                (node_id,),
            )
            (DATA_DIR / node_id).mkdir(exist_ok=True)
        db.commit()


@contextmanager
def transaction():
    with db_lock:
        db = connect_db()
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            block = f.read(CHUNK_SIZE)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def node_is_active(node_id: str) -> bool:
    with transaction() as db:
        row = db.execute(
            "SELECT active FROM nodes WHERE node_id=?", (node_id,)
        ).fetchone()
        return bool(row and row["active"])


def all_nodes() -> List[str]:
    with transaction() as db:
        return [
            row["node_id"]
            for row in db.execute(
                "SELECT node_id FROM nodes ORDER BY node_id"
            ).fetchall()
        ]


def active_nodes() -> List[str]:
    with transaction() as db:
        return [
            row["node_id"]
            for row in db.execute(
                "SELECT node_id FROM nodes WHERE active=1 ORDER BY node_id"
            ).fetchall()
        ]


def replica_path(object_id: str, node_id: str) -> Path:
    return DATA_DIR / node_id / object_id


def select_nodes(object_id: str, count: int) -> List[str]:
    nodes = active_nodes()
    if not nodes:
        return []
    # Stable deterministic placement with a rotating starting point.
    start = int(hashlib.sha256(object_id.encode()).hexdigest(), 16) % len(nodes)
    ordered = nodes[start:] + nodes[:start]
    return ordered[: min(count, len(ordered))]


def get_object(object_id: str):
    with transaction() as db:
        row = db.execute(
            "SELECT * FROM objects WHERE object_id=?", (object_id,)
        ).fetchone()
        if not row:
            raise HTTPException(404, "Object not found")
        return row


def get_replicas(object_id: str):
    with transaction() as db:
        return db.execute(
            "SELECT * FROM replicas WHERE object_id=? ORDER BY node_id",
            (object_id,),
        ).fetchall()


def register_replica(object_id, node_id, checksum, size, version):
    with transaction() as db:
        db.execute("""
        INSERT INTO replicas(object_id,node_id,checksum,size,version)
        VALUES(?,?,?,?,?)
        ON CONFLICT(object_id,node_id) DO UPDATE SET
            checksum=excluded.checksum,
            size=excluded.size,
            version=excluded.version
        """, (object_id, node_id, checksum, size, version))


def remove_replica(object_id, node_id):
    with transaction() as db:
        db.execute(
            "DELETE FROM replicas WHERE object_id=? AND node_id=?",
            (object_id, node_id),
        )


def copy_replica(source: Path, destination: Path):
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_suffix(".tmp")
    shutil.copyfile(source, temp)
    os.replace(temp, destination)


def valid_replica(object_row, replica_row) -> bool:
    node_id = replica_row["node_id"]
    if not node_is_active(node_id):
        return False
    path = replica_path(object_row["object_id"], node_id)
    if not path.exists():
        return False
    if path.stat().st_size != object_row["size"]:
        return False
    return sha256_file(path) == object_row["checksum"]


def find_valid_source(object_id: str):
    obj = get_object(object_id)
    for replica in get_replicas(object_id):
        if valid_replica(obj, replica):
            return replica_path(object_id, replica["node_id"])
    return None


def repair_object(object_id: str):
    obj = get_object(object_id)
    valid_source = find_valid_source(object_id)
    if not valid_source:
        return {"object_id": object_id, "status": "unrecoverable"}

    repaired = []
    target_nodes = select_nodes(object_id, REPLICATION_FACTOR)
    for node_id in target_nodes:
        target = replica_path(object_id, node_id)
        replica = next(
            (r for r in get_replicas(object_id) if r["node_id"] == node_id),
            None,
        )
        if valid_replica(obj, replica) if replica else False:
            continue
        if not node_is_active(node_id):
            continue
        copy_replica(valid_source, target)
        register_replica(
            object_id, node_id, obj["checksum"], obj["size"], obj["version"]
        )
        repaired.append(node_id)

    # Remove metadata for replicas on nodes outside the current placement set.
    with transaction() as db:
        rows = db.execute(
            "SELECT node_id FROM replicas WHERE object_id=?", (object_id,)
        ).fetchall()
        for row in rows:
            if row["node_id"] not in target_nodes:
                db.execute(
                    "DELETE FROM replicas WHERE object_id=? AND node_id=?",
                    (object_id, row["node_id"]),
                )
    return {"object_id": object_id, "status": "repaired", "nodes": repaired}


def verify_object(object_id: str):
    obj = get_object(object_id)
    results = []
    for replica in get_replicas(object_id):
        path = replica_path(object_id, replica["node_id"])
        valid = valid_replica(obj, replica)
        results.append({
            "node_id": replica["node_id"],
            "exists": path.exists(),
            "valid": valid,
        })
    return results


@app.on_event("startup")
def startup():
    init_db()


@app.get("/", response_class=HTMLResponse)
def home():
    return """
    <html>
      <head><title>Vault Object Storage</title></head>
      <body style="font-family:Arial;max-width:900px;margin:40px auto">
        <h1>Vault</h1>
        <p>Fault-tolerant distributed object storage prototype.</p>
        <ul>
          <li><a href="/docs">API documentation</a></li>
          <li><a href="/nodes">Node status</a></li>
          <li><li><a href="/objects">Object list</a></li>
        </ul>
        <h2>Quick upload</h2>
        <form action="/objects" method="post" enctype="multipart/form-data">
          <input type="file" name="file" required>
          <button type="submit">Upload</button>
        </form>
      </body>
    </html>
    """


@app.post("/objects")
async def upload_object(file: UploadFile = File(...)):
    object_id = str(uuid.uuid4())
    temp_path = DATA_DIR / f"{object_id}.upload"
    size = 0
    digest = hashlib.sha256()

    with temp_path.open("wb") as out:
        while True:
            chunk = await file.read(CHUNK_SIZE)
            if not chunk:
                break
            out.write(chunk)
            digest.update(chunk)
            size += len(chunk)

    checksum = digest.hexdigest()
    nodes = select_nodes(object_id, REPLICATION_FACTOR)
    if len(nodes) < REPLICATION_FACTOR:
        temp_path.unlink(missing_ok=True)
        raise HTTPException(503, "Not enough active nodes for replication")

    version = 1
    with transaction() as db:
        db.execute(
            "INSERT INTO objects VALUES(?,?,?,?,?,?)",
            (object_id, file.filename or object_id, size, checksum, time.time(), version),
        )

    try:
        for node_id in nodes:
            destination = replica_path(object_id, node_id)
            copy_replica(temp_path, destination)
            register_replica(object_id, node_id, checksum, size, version)
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise HTTPException(500, "Replication failed")

    temp_path.unlink(missing_ok=True)
    return {
        "object_id": object_id,
        "filename": file.filename,
        "size": size,
        "checksum": checksum,
        "replicas": nodes,
    }


@app.get("/objects")
def list_objects():
    with transaction() as db:
        rows = db.execute(
            "SELECT object_id,object_name,size,checksum,version,created_at FROM objects"
        ).fetchall()
        return [dict(row) for row in rows]


@app.get("/objects/{object_id}")
def download_object(object_id: str):
    obj = get_object(object_id)
    for replica in get_replicas(object_id):
        if valid_replica(obj, replica):
            return FileResponse(
                replica_path(object_id, replica["node_id"]),
                filename=obj["object_name"],
                media_type="application/octet-stream",
            )
    repair_result = repair_object(object_id)
    if repair_result["status"] == "repaired":
        for replica in get_replicas(object_id):
            if valid_replica(obj, replica):
                return FileResponse(
                    replica_path(object_id, replica["node_id"]),
                    filename=obj["object_name"],
                    media_type="application/octet-stream",
                )
    raise HTTPException(503, "No valid replica available")


@app.get("/nodes")
def node_status():
    result = []
    with transaction() as db:
        rows = db.execute("SELECT * FROM nodes ORDER BY node_id").fetchall()
        for row in rows:
            node_id = row["node_id"]
            path = DATA_DIR / node_id
            used = sum(p.stat().st_size for p in path.glob("*") if p.is_file())
            result.append({
                "node_id": node_id,
                "active": bool(row["active"]),
                "used_bytes": used,
                "capacity_bytes": row["capacity"],
            })
    return result


@app.post("/nodes/{node_id}/fail")
def fail_node(node_id: str):
    if node_id not in all_nodes():
        raise HTTPException(404, "Node not found")
    with transaction() as db:
        db.execute("UPDATE nodes SET active=0 WHERE node_id=?", (node_id,))
    return {"node_id": node_id, "active": False}


@app.post("/nodes/{node_id}/recover")
def recover_node(node_id: str):
    if node_id not in all_nodes():
        raise HTTPException(404, "Node not found")
    with transaction() as db:
        db.execute("UPDATE nodes SET active=1 WHERE node_id=?", (node_id,))
    return {"node_id": node_id, "active": True}


@app.post("/verify")
def verify_all():
    with transaction() as db:
        ids = [r["object_id"] for r in db.execute("SELECT object_id FROM objects")]
    return {object_id: verify_object(object_id) for object_id in ids}


@app.post("/repair")
def repair_all():
    with transaction() as db:
        ids = [r["object_id"] for r in db.execute("SELECT object_id FROM objects")]
    return [repair_object(object_id) for object_id in ids]


@app.post("/rebalance")
def rebalance():
    # Rebalance is implemented by repairing each object against current placement.
    with transaction() as db:
        ids = [r["object_id"] for r in db.execute("SELECT object_id FROM objects")]
    return {
        "status": "completed",
        "results": [repair_object(object_id) for object_id in ids],
    }


@app.get("/objects/{object_id}/verify")
def verify_single(object_id: str):
    get_object(object_id)
    return {"object_id": object_id, "replicas": verify_object(object_id)}

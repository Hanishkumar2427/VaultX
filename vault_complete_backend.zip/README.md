# Vault Complete Backend

## Requirements
- Python 3.10 or newer

## Windows setup

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --reload
```

## Linux/macOS setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```

Open:
- Website: http://127.0.0.1:8000
- Swagger: http://127.0.0.1:8000/docs

## API endpoints

- POST /objects - upload a file
- GET /objects - list objects
- GET /objects/{object_id} - download
- GET /objects/{object_id}/verify - verify one object
- POST /verify - verify all objects
- GET /nodes - list node status
- POST /nodes/{node_id}/fail - simulate failure
- POST /nodes/{node_id}/recover - recover node
- POST /repair - manually repair replicas
- POST /rebalance - reconcile replica placement
- GET /health - service health

## Notes

This is an educational local prototype. It uses five local directories as simulated nodes and SQLite for metadata. The background repair worker runs every 15 seconds while the FastAPI process is running.

It is not production-ready distributed storage. It does not provide consensus, independent machines, durable quorum acknowledgements, full network partition handling, or capacity-aware rebalancing.

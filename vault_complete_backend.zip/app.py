import asyncio
import hashlib
import os
import shutil
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel

# ============================================================
# CONFIGURATION
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
STORAGE_DIR = BASE_DIR / "storage_nodes"
DATABASE_PATH = BASE_DIR / "vault.db"

NODE_COUNT = 5
REPLICATION_FACTOR = 3
CHUNK_SIZE = 1024 * 1024
REPAIR_INTERVAL_SECONDS = 15

app = FastAPI(
    title="Vault Distributed Object Storage Backend",
    version="2.0.0",
    description="Educational fault-tolerant object storage prototype",
)

database_lock = threading.RLock()
file_lock = threading.RLock()
background_task: Optional[asyncio.Task] = None


# ============================================================
# DATABASE
# ============================================================

def get_connection():
    connection = sqlite3.connect(
        DATABASE_PATH,
        timeout=30,
        check_same_thread=False,
    )
    connection.row_factory = sqlite3.Row
    return connection


@contextmanager
def transaction():
    with database_lock:
        connection = get_connection()
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()


def initialize_database():
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)

    with transaction() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS objects (
                object_id TEXT PRIMARY KEY,
                object_name TEXT NOT NULL,
                object_size INTEGER NOT NULL,
                checksum TEXT NOT NULL,
                version INTEGER NOT NULL,
                created_at REAL NOT NULL
            )
        """)

        db.execute("""
            CREATE TABLE IF NOT EXISTS nodes (
                node_id TEXT PRIMARY KEY,
                active INTEGER NOT NULL DEFAULT 1,
                capacity_bytes INTEGER NOT NULL DEFAULT 10737418240
            )
        """)

        db.execute("""
            CREATE TABLE IF NOT EXISTS replicas (
                object_id TEXT NOT NULL,
                node_id TEXT NOT NULL,
                checksum TEXT NOT NULL,
                object_size INTEGER NOT NULL,
                version INTEGER NOT NULL,
                updated_at REAL NOT NULL,
                PRIMARY KEY (object_id, node_id),
                FOREIGN KEY (object_id) REFERENCES objects(object_id),
                FOREIGN KEY (node_id) REFERENCES nodes(node_id)
            )
        """)

        for index in range(1, NODE_COUNT + 1):
            node_id = f"node-{index}"
            db.execute(
                """
                INSERT OR IGNORE INTO nodes(node_id, active)
                VALUES (?, 1)
                """,
                (node_id,),
            )
            (STORAGE_DIR / node_id).mkdir(parents=True, exist_ok=True)


# ============================================================
# FILE AND CHECKSUM HELPERS
# ============================================================

def object_path(object_id: str, node_id: str) -> Path:
    return STORAGE_DIR / node_id / object_id


def calculate_checksum(path: Path) -> str:
    digest = hashlib.sha256()

    with path.open("rb") as file:
        while True:
            chunk = file.read(CHUNK_SIZE)
            if not chunk:
                break
            digest.update(chunk)

    return digest.hexdigest()


def copy_atomically(source: Path, destination: Path):
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = destination.with_suffix(".tmp")

    with file_lock:
        shutil.copyfile(source, temporary_path)
        os.replace(temporary_path, destination)


def get_object_or_404(object_id: str):
    with transaction() as db:
        row = db.execute(
            "SELECT * FROM objects WHERE object_id = ?",
            (object_id,),
        ).fetchone()

    if row is None:
        raise HTTPException(status_code=404, detail="Object not found")

    return row


# ============================================================
# NODE MANAGEMENT
# ============================================================

def get_all_nodes():
    with transaction() as db:
        rows = db.execute(
            "SELECT * FROM nodes ORDER BY node_id"
        ).fetchall()
    return rows


def get_active_nodes():
    with transaction() as db:
        rows = db.execute(
            """
            SELECT * FROM nodes
            WHERE active = 1
            ORDER BY node_id
            """
        ).fetchall()
    return rows


def node_exists(node_id: str) -> bool:
    with transaction() as db:
        row = db.execute(
            "SELECT node_id FROM nodes WHERE node_id = ?",
            (node_id,),
        ).fetchone()
    return row is not None


def node_is_active(node_id: str) -> bool:
    with transaction() as db:
        row = db.execute(
            "SELECT active FROM nodes WHERE node_id = ?",
            (node_id,),
        ).fetchone()
    return bool(row and row["active"])


def select_target_nodes(object_id: str, count: int):
    nodes = [row["node_id"] for row in get_active_nodes()]

    if not nodes:
        return []

    starting_index = (
        int(hashlib.sha256(object_id.encode()).hexdigest(), 16)
        % len(nodes)
    )

    ordered_nodes = nodes[starting_index:] + nodes[:starting_index]
    return ordered_nodes[: min(count, len(ordered_nodes))]


# ============================================================
# REPLICA METADATA
# ============================================================

def get_replicas(object_id: str):
    with transaction() as db:
        rows = db.execute(
            """
            SELECT * FROM replicas
            WHERE object_id = ?
            ORDER BY node_id
            """,
            (object_id,),
        ).fetchall()
    return rows


def get_replica(object_id: str, node_id: str):
    with transaction() as db:
        row = db.execute(
            """
            SELECT * FROM replicas
            WHERE object_id = ? AND node_id = ?
            """,
            (object_id, node_id),
        ).fetchone()
    return row


def save_replica_metadata(
    object_id: str,
    node_id: str,
    checksum: str,
    object_size: int,
    version: int,
):
    with transaction() as db:
        db.execute(
            """
            INSERT INTO replicas(
                object_id,
                node_id,
                checksum,
                object_size,
                version,
                updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(object_id, node_id)
            DO UPDATE SET
                checksum = excluded.checksum,
                object_size = excluded.object_size,
                version = excluded.version,
                updated_at = excluded.updated_at
            """,
            (
                object_id,
                node_id,
                checksum,
                object_size,
                version,
                time.time(),
            ),
        )


def delete_replica_metadata(object_id: str, node_id: str):
    with transaction() as db:
        db.execute(
            """
            DELETE FROM replicas
            WHERE object_id = ? AND node_id = ?
            """,
            (object_id, node_id),
        )


# ============================================================
# INTEGRITY VALIDATION
# ============================================================

def is_replica_valid(object_row, replica_row) -> bool:
    if replica_row is None:
        return False

    node_id = replica_row["node_id"]

    if not node_is_active(node_id):
        return False

    path = object_path(object_row["object_id"], node_id)

    if not path.exists() or not path.is_file():
        return False

    if path.stat().st_size != object_row["object_size"]:
        return False

    actual_checksum = calculate_checksum(path)

    return actual_checksum == object_row["checksum"]


def find_valid_source(object_id: str):
    object_row = get_object_or_404(object_id)

    for replica in get_replicas(object_id):
        if is_replica_valid(object_row, replica):
            return object_path(object_id, replica["node_id"])

    return None


# ============================================================
# REPAIR AND REBALANCING
# ============================================================

def repair_object(object_id: str):
    object_row = get_object_or_404(object_id)
    source = find_valid_source(object_id)

    if source is None:
        return {
            "object_id": object_id,
            "status": "unrecoverable",
            "message": "No valid source replica exists",
        }

    target_nodes = select_target_nodes(
        object_id,
        REPLICATION_FACTOR,
    )

    if len(target_nodes) < REPLICATION_FACTOR:
        return {
            "object_id": object_id,
            "status": "waiting_for_nodes",
            "message": "Not enough active nodes for full replication",
            "target_nodes": target_nodes,
        }

    repaired_nodes = []

    for node_id in target_nodes:
        existing_replica = get_replica(object_id, node_id)

        if is_replica_valid(object_row, existing_replica):
            continue

        destination = object_path(object_id, node_id)

        copy_atomically(source, destination)

        save_replica_metadata(
            object_id=object_id,
            node_id=node_id,
            checksum=object_row["checksum"],
            object_size=object_row["object_size"],
            version=object_row["version"],
        )

        repaired_nodes.append(node_id)

    # Remove stale replica metadata outside current placement.
    with transaction() as db:
        rows = db.execute(
            """
            SELECT node_id FROM replicas
            WHERE object_id = ?
            """,
            (object_id,),
        ).fetchall()

        for row in rows:
            if row["node_id"] not in target_nodes:
                db.execute(
                    """
                    DELETE FROM replicas
                    WHERE object_id = ? AND node_id = ?
                    """,
                    (object_id, row["node_id"]),
                )

    return {
        "object_id": object_id,
        "status": "repaired",
        "target_nodes": target_nodes,
        "repaired_nodes": repaired_nodes,
    }


def repair_all_objects():
    with transaction() as db:
        rows = db.execute(
            "SELECT object_id FROM objects"
        ).fetchall()

    results = []

    for row in rows:
        try:
            results.append(repair_object(row["object_id"]))
        except Exception as error:
            results.append({
                "object_id": row["object_id"],
                "status": "error",
                "message": str(error),
            })

    return results


# ============================================================
# BACKGROUND WORKER
# ============================================================

async def repair_worker():
    while True:
        try:
            await asyncio.to_thread(repair_all_objects)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            print(f"[repair-worker] error: {error}")

        await asyncio.sleep(REPAIR_INTERVAL_SECONDS)


@app.on_event("startup")
async def startup_event():
    global background_task

    initialize_database()
    background_task = asyncio.create_task(repair_worker())


@app.on_event("shutdown")
async def shutdown_event():
    global background_task

    if background_task is not None:
        background_task.cancel()

        try:
            await background_task
        except asyncio.CancelledError:
            pass


# ============================================================
# WEB ROUTES
# ============================================================

@app.get("/", response_class=HTMLResponse)
def home():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Vault Backend</title>
        <style>
            body {
                font-family: Arial;
                max-width: 850px;
                margin: 40px auto;
                line-height: 1.6;
            }
            .card {
                border: 1px solid #ddd;
                border-radius: 12px;
                padding: 20px;
            }
        </style>
    </head>
    <body>
        <div class="card">
            <h1>Vault Distributed Object Storage</h1>
            <p>Backend is running.</p>
            <p><a href="/docs">Open Swagger API Documentation</a></p>
            <h2>Upload object</h2>
            <form action="/objects" method="post"
                  enctype="multipart/form-data">
                <input type="file" name="file" required>
                <button type="submit">Upload</button>
            </form>
        </div>
    </body>
    </html>
    """


# ============================================================
# OBJECT ROUTES
# ============================================================

@app.post("/objects")
async def upload_object(file: UploadFile = File(...)):
    object_id = str(uuid.uuid4())
    temporary_path = STORAGE_DIR / f"{object_id}.upload"

    object_size = 0
    digest = hashlib.sha256()

    try:
        with temporary_path.open("wb") as output:
            while True:
                chunk = await file.read(CHUNK_SIZE)

                if not chunk:
                    break

                output.write(chunk)
                digest.update(chunk)
                object_size += len(chunk)

        checksum = digest.hexdigest()
        target_nodes = select_target_nodes(
            object_id,
            REPLICATION_FACTOR,
        )

        if len(target_nodes) < REPLICATION_FACTOR:
            raise HTTPException(
                status_code=503,
                detail="Not enough active nodes for replication",
            )

        version = 1

        with transaction() as db:
            db.execute(
                """
                INSERT INTO objects(
                    object_id,
                    object_name,
                    object_size,
                    checksum,
                    version,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    object_id,
                    file.filename or object_id,
                    object_size,
                    checksum,
                    version,
                    time.time(),
                ),
            )

        for node_id in target_nodes:
            destination = object_path(object_id, node_id)
            copy_atomically(temporary_path, destination)

            save_replica_metadata(
                object_id=object_id,
                node_id=node_id,
                checksum=checksum,
                object_size=object_size,
                version=version,
            )

        return {
            "object_id": object_id,
            "filename": file.filename,
            "size": object_size,
            "checksum": checksum,
            "version": version,
            "replicas": target_nodes,
        }

    finally:
        temporary_path.unlink(missing_ok=True)


@app.get("/objects")
def list_objects():
    with transaction() as db:
        rows = db.execute(
            """
            SELECT object_id, object_name, object_size,
                   checksum, version, created_at
            FROM objects
            ORDER BY created_at DESC
            """
        ).fetchall()

    return [dict(row) for row in rows]


@app.get("/objects/{object_id}")
def download_object(object_id: str):
    object_row = get_object_or_404(object_id)

    for replica in get_replicas(object_id):
        if is_replica_valid(object_row, replica):
            return FileResponse(
                path=object_path(object_id, replica["node_id"]),
                filename=object_row["object_name"],
                media_type="application/octet-stream",
            )

    repair_result = repair_object(object_id)

    if repair_result["status"] == "repaired":
        object_row = get_object_or_404(object_id)

        for replica in get_replicas(object_id):
            if is_replica_valid(object_row, replica):
                return FileResponse(
                    path=object_path(object_id, replica["node_id"]),
                    filename=object_row["object_name"],
                    media_type="application/octet-stream",
                )

    raise HTTPException(
        status_code=503,
        detail="No valid replica is currently available",
    )


# ============================================================
# NODE ROUTES
# ============================================================

@app.get("/nodes")
def list_nodes():
    result = []

    for node in get_all_nodes():
        node_id = node["node_id"]
        directory = STORAGE_DIR / node_id

        used_bytes = sum(
            item.stat().st_size
            for item in directory.iterdir()
            if item.is_file()
        )

        result.append({
            "node_id": node_id,
            "active": bool(node["active"]),
            "used_bytes": used_bytes,
            "capacity_bytes": node["capacity_bytes"],
        })

    return result


@app.post("/nodes/{node_id}/fail")
def fail_node(node_id: str):
    if not node_exists(node_id):
        raise HTTPException(status_code=404, detail="Node not found")

    with transaction() as db:
        db.execute(
            """
            UPDATE nodes SET active = 0
            WHERE node_id = ?
            """,
            (node_id,),
        )

    return {
        "node_id": node_id,
        "active": False,
        "message": "Node marked as failed",
    }


@app.post("/nodes/{node_id}/recover")
def recover_node(node_id: str):
    if not node_exists(node_id):
        raise HTTPException(status_code=404, detail="Node not found")

    with transaction() as db:
        db.execute(
            """
            UPDATE nodes SET active = 1
            WHERE node_id = ?
            """,
            (node_id,),
        )

    return {
        "node_id": node_id,
        "active": True,
        "message": "Node recovered",
    }


# ============================================================
# VERIFICATION AND ADMIN ROUTES
# ============================================================

@app.get("/objects/{object_id}/verify")
def verify_object(object_id: str):
    object_row = get_object_or_404(object_id)
    result = []

    for replica in get_replicas(object_id):
        path = object_path(object_id, replica["node_id"])

        result.append({
            "node_id": replica["node_id"],
            "exists": path.exists(),
            "active": node_is_active(replica["node_id"]),
            "valid": is_replica_valid(object_row, replica),
        })

    return {
        "object_id": object_id,
        "replicas": result,
    }


@app.post("/verify")
def verify_all_objects():
    with transaction() as db:
        rows = db.execute(
            "SELECT object_id FROM objects"
        ).fetchall()

    results = {}

    for row in rows:
        object_id = row["object_id"]
        results[object_id] = verify_object(object_id)

    return results


@app.post("/repair")
def manual_repair():
    return {
        "status": "completed",
        "results": repair_all_objects(),
    }


@app.post("/rebalance")
def rebalance():
    return {
        "status": "completed",
        "message": (
            "Replica placement reconciliation completed. "
            "This prototype does not perform capacity-aware balancing."
        ),
        "results": repair_all_objects(),
    }


@app.get("/health")
def health():
    active_count = len(get_active_nodes())

    return {
        "status": "ok",
        "active_nodes": active_count,
        "total_nodes": NODE_COUNT,
        "replication_factor": REPLICATION_FACTOR,
        "repair_interval_seconds": REPAIR_INTERVAL_SECONDS,
    }
